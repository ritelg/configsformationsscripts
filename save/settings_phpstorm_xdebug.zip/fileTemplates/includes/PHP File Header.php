/**
 * This file is part of the Enjoy Events Website.
 *
 * (c) Gaetan Ritel <ritelg@yahoo.fr>
 *
 */